package com.example.proyekakhirjmp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    private EditText editText_username, editText_password;
    private Button bt_login;

    private String username = "JasmineHigh";
    private String password = "Demo123456";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editText_username = findViewById(R.id.editText_username);
        editText_password = findViewById(R.id.editText_password);
        bt_login = findViewById(R.id.bt_login);

        bt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (editText_username.getText().toString().equalsIgnoreCase(username) && editText_password.getText().toString().equalsIgnoreCase(password)) {
                    Intent login = new Intent(Login.this, MainActivity.class);
                    startActivity(login);

                    Toast.makeText(Login.this, "LOGIN BERHASIL :)", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText( Login.this, "LOGIN GAGAL :(", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}