package com.example.apk_sertifikasi;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ListBiodata extends AppCompatActivity {
    protected Cursor cursor;
    DataHelper dbHelper;
    Button bt_list_kembali;
    TextView tv_list_no, tv_list_nama, tv_list_jk, tv_list_tgl, tv_list_alamat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_biodata);
        dbHelper = new DataHelper(this);
        tv_list_no = (TextView) findViewById(R.id.tv_list_no);
        tv_list_nama = (TextView) findViewById(R.id.tv_list_nama);
        tv_list_jk = (TextView) findViewById(R.id.tv_list_jk);
        tv_list_tgl = (TextView) findViewById(R.id.tv_list_tgl);
        tv_list_alamat = (TextView) findViewById(R.id.tv_list_alamat);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        cursor = db.rawQuery("SELECT * FROM mahasiswa WHERE nama = '" +
                getIntent().getStringExtra("nama") + "'",null);
        cursor.moveToFirst();

        if(cursor.getCount()>0)
        {
            cursor.moveToPosition(0);
            tv_list_no.setText(cursor.getString(0).toString());
            tv_list_nama.setText(cursor.getString(1).toString());
            tv_list_jk.setText(cursor.getString(2).toString());
            tv_list_tgl.setText(cursor.getString(3).toString());
            tv_list_alamat.setText(cursor.getString(4).toString());
        }
        bt_list_kembali = (Button) findViewById(R.id.bt_list_kembali);
        bt_list_kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}