package com.example.apk_sertifikasi;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateBiodata extends AppCompatActivity {
    protected Cursor cursor;
    DataHelper dbHelper;
    Button bt_update, bt_upt_kembali;
    EditText et_upt_no, et_upt_name, et_upt_jk, et_upt_tgl, et_upt_alamat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_biodata);
       dbHelper = new DataHelper(this);
       et_upt_no= (EditText)findViewById(R.id.et_upt_no);
       et_upt_name= (EditText)findViewById(R.id.et_upt_name);
       et_upt_jk= (EditText)findViewById(R.id.et_upt_jk);
       et_upt_tgl= (EditText)findViewById(R.id.et_upt_tgl);
       et_upt_alamat= (EditText)findViewById(R.id.et_upt_alamat);
       SQLiteDatabase db = dbHelper.getReadableDatabase();
        cursor = db.rawQuery("SELECT * FROM mahasiswa WHERE nama = '" +
                getIntent().getStringExtra("nama") + "'",null);
        cursor.moveToFirst();

        if(cursor.getCount()>0)
        {
            cursor.moveToPosition(0);
            et_upt_no.setText(cursor.getString(0).toString());
            et_upt_name.setText(cursor.getString(1).toString());
            et_upt_jk.setText(cursor.getString(2).toString());
            et_upt_tgl.setText(cursor.getString(3).toString());
            et_upt_alamat.setText(cursor.getString(4).toString());
        }
        bt_update = (Button) findViewById(R.id.bt_update);
        bt_upt_kembali = (Button) findViewById(R.id.bt_upt_kembali);
        bt_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                db.execSQL("update mahasiswa set nama='" +
                        et_upt_name.getText().toString() + "', jk= '"+
                        et_upt_jk.getText().toString() + "', tgl= '"+
                        et_upt_tgl.getText().toString() + "', alamat= '"+
                        et_upt_alamat.getText().toString() + "' where no='"+
                        et_upt_no.getText().toString() + "'");
                Toast.makeText(getApplicationContext(),"Berhasil Input", Toast.LENGTH_LONG).show();
                MainActivity.ma.RefreshList();
                finish();
            }
        });
    }
}