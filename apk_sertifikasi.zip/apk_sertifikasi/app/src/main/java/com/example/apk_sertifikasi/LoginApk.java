package com.example.apk_sertifikasi;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LoginApk extends AppCompatActivity {

    Button bt_login;
    EditText et_username, et_password;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_apk);

        et_username = (EditText) findViewById(R.id.et_username);
        et_password = (EditText) findViewById(R.id.et_password);
        bt_login = (Button) findViewById(R.id.bt_login);

        bt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(et_username.getText().toString().equals("jasmineadm") && et_password.getText().toString().equals("password")){
                    //correct
                    Toast.makeText(LoginApk.this, "Login Success",Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(LoginApk.this, MainActivity.class);
                    startActivity(intent);
                }else
                    //incorrect
                    Toast.makeText(LoginApk.this, "Login Failed", Toast.LENGTH_SHORT).show();
            }
        });

    }
}