package com.example.apk_sertifikasi;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateBiodata extends AppCompatActivity {
    protected Cursor cursor;
    DataHelper dbHelper;
    Button bt_simpan, bt_kembali;
    EditText et_nomor, et_nama, et_jk, et_tglhr, et_alamat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_biodata);

        dbHelper = new DataHelper(this);
        et_nomor = (EditText) findViewById(R.id.et_nomor);
        et_nama = (EditText) findViewById(R.id.et_nama);
        et_jk = (EditText) findViewById(R.id.et_jk);
        et_tglhr = (EditText) findViewById(R.id.et_tglhr);
        et_alamat = (EditText) findViewById(R.id.et_alamat);
        bt_kembali = (Button) findViewById(R.id.bt_kembali);
        bt_simpan = (Button) findViewById(R.id.bt_simpan);
                bt_simpan.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        SQLiteDatabase db = dbHelper.getWritableDatabase();
                        db.execSQL("insert into mahasiswa(no,nama,jk,tgl,alamat) values('" +
                                et_nomor.getText().toString()+"', '"+
                                et_nama.getText().toString()+"', '"+
                                et_jk.getText().toString()+"', '"+
                                et_tglhr.getText().toString()+"', '"+
                                et_alamat.getText().toString()+"')");
                        Toast.makeText(getApplicationContext(),"Berhasil Input", Toast.LENGTH_LONG).show();
                        MainActivity.ma.RefreshList();
                        finish();
                    }
                });
        bt_kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

//    public boolean onCreateOptionMenu (Menu menu){
//        getMenuInflater().inflate(R.menu.menu_main, menu);
//        return true;
//    }
}